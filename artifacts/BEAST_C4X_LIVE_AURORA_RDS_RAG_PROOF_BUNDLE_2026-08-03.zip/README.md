# BEAST C4-X Live Aurora/RDS RAG Proof Bundle

This bundle contains the C4-X external breakthrough benchmark scaffold, the live Aurora/Postgres pgvector RAG adapter, the scoped corpus seeder, focused tests, plan update, and the `pgvector-rag-real-run-005` evidence receipt.

No `.beast` env files, API keys, DSNs, IAM tokens, passwords, or provider secrets are included.

Key receipt: `sha256:0c4c1d9dcc6596c618fd80c7281a24c66bd734bdd818bb46e0c265b0a3e15ba2`

Observed score in the included live run:

- BEAST C4-X: 12/12 semantic, 12/12 artifact custody, 12/12 proof-first, total 192.
- Live Aurora RDS RAG: 12/12 semantic, 0/12 artifact custody, 0/12 proof-first, total 84.
