# BEAST C4-X document vision adjudication live Gemini snapshot

Includes the independent Gemini/human/oracle adjudicator, Gemini sidecar runner with auto model discovery, focused tests, plan update, dry-run refusal evidence, and live Gemini-only evidence showing partial gates unlock without final truth credit.
