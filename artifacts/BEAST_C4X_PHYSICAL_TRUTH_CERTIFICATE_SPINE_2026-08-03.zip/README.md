# BEAST C4-X physical truth certificate spine

Adds hard gates for C4-X truth, Sensorium, BPF, Crystal Bus, memfd, Guardian, reuse, PQ transport, Commons replication, route resilience, PSI governance, and XDP scope. Includes a pending receipt proving public credit is refused until live sidecars are attached.
