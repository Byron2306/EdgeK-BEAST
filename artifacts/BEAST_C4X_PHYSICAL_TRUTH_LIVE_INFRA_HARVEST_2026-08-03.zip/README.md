# BEAST C4-X physical truth live infrastructure harvest

Includes the hard-gated physical truth certificate, conservative live-infra sidecar harvester, BPF preflight, Commons ML-KEM receipts, harvested certificate, and tests. It records live infrastructure without granting final physical-truth credit where attack-suite receipts are still missing.
