#!/usr/bin/env python3
"""Run a live Commons ML-KEM-768 key-agreement gauntlet.

Receipts store public material, ciphertext digests, transcript digests, and
confirmation digests.  They never store shared secrets.
"""
from __future__ import annotations

import argparse
import base64
import json
import sys
from pathlib import Path
from typing import Any

import httpx

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from app.kernel.commons.ml_kem import (
    ML_KEM_ALGORITHM,
    challenge_confirmation_body,
    confirmation_mac,
    encapsulate,
)
from app.kernel.commons.remote_protocol import canonical_json, sha256_bytes
from app.kernel.compute.residual_contracts import sha256_digest, utc_now_iso


DEFAULT_NODES = (
    "http://127.0.0.1:8111",
    "http://127.0.0.1:8112",
    "http://127.0.0.1:8113",
)


def run_commons_ml_kem_gauntlet(
    *,
    nodes: tuple[str, ...] = DEFAULT_NODES,
    run_id: str | None = None,
    evidence_root: str | Path = REPO_ROOT / "evidence" / "commons-ml-kem",
    timeout_seconds: float = 10.0,
) -> dict[str, Any]:
    evidence = Path(evidence_root)
    evidence.mkdir(parents=True, exist_ok=True)
    run_id = run_id or utc_now_iso().replace(":", "").replace("+", "z")
    node_results = []
    failures = []
    with httpx.Client(timeout=timeout_seconds) as client:
        for index, base_url in enumerate(nodes):
            try:
                node_results.append(_probe_node(client, base_url.rstrip("/"), index=index))
            except Exception as exc:
                failures.append({
                    "base_url": base_url,
                    "failure": f"{type(exc).__name__}: {exc}",
                })
    pairwise = _pairwise_matrix(node_results)
    receipt = {
        "beast_object_type": "commons_ml_kem_gauntlet_receipt",
        "version": "1.0",
        "run_id": run_id,
        "observed_at": utc_now_iso(),
        "algorithm": ML_KEM_ALGORITHM,
        "node_count": len(node_results),
        "nodes_requested": list(nodes),
        "nodes": node_results,
        "pairwise_transcript_matrix": pairwise,
        "failure_count": len(failures),
        "failures": failures,
        "secret_storage_policy": "shared_secret_bytes_never_serialized",
        "status": "passed" if len(node_results) == len(nodes) and not failures and all(item["confirmed"] for item in node_results) else "failed",
    }
    receipt["receipt_digest"] = sha256_digest(receipt)
    json_path = evidence / f"{run_id}.json"
    md_path = evidence / f"{run_id}.md"
    json_path.write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    md_path.write_text(_markdown(receipt), encoding="utf-8")
    (evidence / "latest.json").write_text(json.dumps(receipt, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (evidence / "latest.md").write_text(_markdown(receipt), encoding="utf-8")
    receipt["evidence_paths"] = {
        "json": str(json_path),
        "markdown": str(md_path),
        "latest_json": str(evidence / "latest.json"),
        "latest_markdown": str(evidence / "latest.md"),
    }
    return receipt


def _probe_node(client: httpx.Client, base_url: str, *, index: int) -> dict[str, Any]:
    health = client.get(base_url + "/health")
    health.raise_for_status()
    health_payload = health.json()
    key_response = client.get(base_url + "/v1/ml-kem/key")
    key_response.raise_for_status()
    key_payload = key_response.json()
    document = dict(key_payload["document"])
    if document["algorithm"] != ML_KEM_ALGORITHM:
        raise RuntimeError("unexpected ML-KEM algorithm: " + str(document["algorithm"]))
    public_key = base64.b64decode(document["public_key_b64"], validate=True)
    if sha256_bytes(public_key) != document["public_key_digest"]:
        raise RuntimeError("ML-KEM public key digest mismatch")
    ciphertext, shared_secret = encapsulate(public_key, algorithm=document["algorithm"])
    nonce = f"commons-ml-kem-gauntlet:{index}:{sha256_bytes(public_key).removeprefix('sha256:')[:24]}"
    transcript = {
        "node_id": document["node_id"],
        "base_url": base_url,
        "algorithm": document["algorithm"],
        "public_key_digest": document["public_key_digest"],
        "health_digest": sha256_digest(health_payload),
    }
    transcript_digest = sha256_bytes(canonical_json(transcript))
    challenge = client.post(base_url + "/v1/ml-kem/challenge", json={
        "public_key_digest": document["public_key_digest"],
        "ciphertext_b64": base64.b64encode(ciphertext).decode("ascii"),
        "challenge_nonce": nonce,
        "transcript_digest": transcript_digest,
    })
    challenge.raise_for_status()
    challenge_payload = challenge.json()
    confirmation = dict(challenge_payload["confirmation"])
    body = challenge_confirmation_body(
        node_id=document["node_id"],
        algorithm=document["algorithm"],
        public_key_digest=document["public_key_digest"],
        ciphertext_digest=sha256_bytes(ciphertext),
        challenge_nonce=nonce,
        transcript_digest=transcript_digest,
    )
    expected_mac = confirmation_mac(shared_secret, body)
    confirmed = confirmation.get("confirmation_mac_b64") == expected_mac
    return {
        "base_url": base_url,
        "node_id": str(health_payload.get("node_id") or document["node_id"]),
        "health_digest": sha256_digest(health_payload),
        "health_ok": health_payload.get("ok") is True,
        "algorithm": document["algorithm"],
        "public_key_digest": document["public_key_digest"],
        "public_key_document_digest": document["document_digest"],
        "public_key_signature_digest": sha256_digest(str(key_payload.get("node_signature") or "")),
        "ciphertext_digest": sha256_bytes(ciphertext),
        "ciphertext_size_bytes": len(ciphertext),
        "shared_secret_size_bytes": len(shared_secret),
        "transcript_digest": transcript_digest,
        "challenge_confirmation_digest": challenge_payload["confirmation_digest"],
        "challenge_signature_digest": sha256_digest(str(challenge_payload.get("node_signature") or "")),
        "confirmed": confirmed,
        "secret_exported": False,
    }


def _pairwise_matrix(nodes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    rows = []
    for source in nodes:
        for target in nodes:
            if source["node_id"] == target["node_id"]:
                continue
            rows.append({
                "from_node_id": source["node_id"],
                "to_node_id": target["node_id"],
                "algorithm": ML_KEM_ALGORITHM,
                "source_health_digest": source["health_digest"],
                "target_public_key_digest": target["public_key_digest"],
                "pair_transcript_digest": sha256_digest({
                    "from": source["node_id"],
                    "to": target["node_id"],
                    "algorithm": ML_KEM_ALGORITHM,
                    "source_health_digest": source["health_digest"],
                    "target_public_key_digest": target["public_key_digest"],
                }),
            })
    return rows


def _markdown(receipt: dict[str, Any]) -> str:
    lines = [
        f"# Commons ML-KEM gauntlet — {receipt['run_id']}",
        "",
        f"- Status: `{receipt['status']}`",
        f"- Receipt digest: `{receipt['receipt_digest']}`",
        f"- Algorithm: `{receipt['algorithm']}`",
        f"- Nodes confirmed: {sum(1 for item in receipt['nodes'] if item['confirmed'])} / {len(receipt['nodes'])}",
        f"- Pairwise transcript edges: {len(receipt['pairwise_transcript_matrix'])}",
        f"- Secret policy: `{receipt['secret_storage_policy']}`",
        "",
    ]
    for node in receipt["nodes"]:
        lines.extend([
            f"## {node['node_id']}",
            "",
            f"- Base URL: `{node['base_url']}`",
            f"- Public key digest: `{node['public_key_digest']}`",
            f"- Ciphertext digest: `{node['ciphertext_digest']}`",
            f"- Confirmation digest: `{node['challenge_confirmation_digest']}`",
            f"- Confirmed: `{node['confirmed']}`",
            "",
        ])
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--node", action="append", dest="nodes", help="Commons node base URL; repeatable")
    parser.add_argument("--run-id", default=None)
    parser.add_argument("--evidence-root", default="evidence/commons-ml-kem")
    args = parser.parse_args()
    receipt = run_commons_ml_kem_gauntlet(
        nodes=tuple(args.nodes or DEFAULT_NODES),
        run_id=args.run_id,
        evidence_root=args.evidence_root,
    )
    print(json.dumps({
        "status": receipt["status"],
        "receipt_digest": receipt["receipt_digest"],
        "node_count": receipt["node_count"],
        "evidence_paths": receipt["evidence_paths"],
    }, sort_keys=True, indent=2))


if __name__ == "__main__":
    main()
