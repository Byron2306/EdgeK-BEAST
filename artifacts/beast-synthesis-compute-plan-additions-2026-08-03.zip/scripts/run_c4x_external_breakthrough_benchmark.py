#!/usr/bin/env python3
"""Run a post-freeze held-out benchmark for BEAST C4-X.

The benchmark freezes the engine hash before case generation, accepts an
evaluator seed, generates randomized held-out operational scenarios, and
compares BEAST against transparent baseline adapters. The baseline adapters are
deliberately simple/reference implementations; public third-party runs should
replace them with independently maintained RAG/template/rule/KG/model systems
while preserving this receipt schema.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
import sys
from dataclasses import asdict
from pathlib import Path
from typing import Any, Mapping

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from app.kernel.compute.deterministic_intelligence import (  # noqa: E402
    ClaimStatus,
    DeterministicIntelligenceEngine,
    Family,
    Scenario,
    canonical_json,
    default_visual_assets,
    make_fact,
    make_policy,
    make_rule,
    result_to_dict,
    sha256_digest,
    utc_now_iso,
)


BASELINES = (
    "rag_nearest_exemplar",
    "cached_named_template",
    "rule_engine_text_only",
    "knowledge_graph_topology_only",
    "model_generated_multimodal_stub",
)


def run_breakthrough_benchmark(
    *,
    evaluator_seed: str,
    case_count_per_family: int = 4,
    evidence_root: str | Path = REPO_ROOT / "evidence" / "c4x-external-breakthrough-benchmark",
    run_id: str | None = None,
) -> dict[str, Any]:
    engine_path = REPO_ROOT / "app/kernel/compute/deterministic_intelligence.py"
    engine_freeze_digest = "sha256:" + hashlib.sha256(engine_path.read_bytes()).hexdigest()
    generator_seed_digest = sha256_digest({
        "engine_freeze_digest": engine_freeze_digest,
        "evaluator_seed": evaluator_seed,
        "case_count_per_family": case_count_per_family,
    })
    scenarios = generate_heldout_scenarios(
        evaluator_seed=evaluator_seed,
        engine_freeze_digest=engine_freeze_digest,
        case_count_per_family=case_count_per_family,
    )
    engine = DeterministicIntelligenceEngine()
    cases: dict[str, Any] = {}
    baseline_scores = {name: _empty_baseline_score() for name in BASELINES}
    beast_score = _empty_baseline_score()
    for scenario in scenarios:
        beast_result = engine.compose(scenario)
        expected = _expected_from_beast(beast_result)
        beast_eval = _evaluate_output(
            expected,
            {
                "system_id": "beast_c4x",
                "answer_text": beast_result.text_artifact.content.decode("utf-8"),
                "visual_bytes": beast_result.visual_artifact.content,
                "proof_graph_digest": beast_result.proof_graph.graph_digest,
                "text_artifact_digest": beast_result.text_artifact.digest,
                "rendered_artifact_digest": beast_result.visual_artifact.digest,
                "joined_verification": beast_result.joined_receipt["joined_verification"],
                "current_claim_valid": beast_result.joined_receipt["current_claim_valid"],
                "status": beast_result.joined_receipt["status"],
                "provider_calls_used": 0,
                "proof_first": True,
                "artifact_custody_valid": True,
            },
        )
        _accumulate(beast_score, beast_eval)
        baseline_outputs = {name: _baseline_output(name, scenario) for name in BASELINES}
        baseline_evals = {}
        for name, output in baseline_outputs.items():
            evaluated = _evaluate_output(expected, output)
            baseline_evals[name] = evaluated
            _accumulate(baseline_scores[name], evaluated)
        cases[scenario.scenario_id] = {
            "scenario": _scenario_public(scenario),
            "expected": expected,
            "beast": {
                "evaluation": beast_eval,
                "joined_receipt": dict(beast_result.joined_receipt),
                "proof_graph": result_to_dict(beast_result)["proof_graph"],
            },
            "baselines": baseline_evals,
        }
    system_scores = {"beast_c4x": _finalize_score(beast_score, len(scenarios))}
    system_scores.update({name: _finalize_score(score, len(scenarios)) for name, score in baseline_scores.items()})
    breakthrough_pass = (
        system_scores["beast_c4x"]["semantic_correct"] == len(scenarios)
        and system_scores["beast_c4x"]["artifact_custody_valid"] == len(scenarios)
        and system_scores["beast_c4x"]["provider_calls_used"] == 0
        and all(
            system_scores["beast_c4x"]["total_score"] > system_scores[name]["total_score"]
            for name in BASELINES
        )
    )
    scorecard = {
        "engine_freeze_digest": engine_freeze_digest,
        "evaluator_seed": evaluator_seed,
        "generator_seed_digest": generator_seed_digest,
        "heldout_cases": len(scenarios),
        "cross_modal_families": len({scenario.family.value for scenario in scenarios}),
        "randomized_service_names": len({scenario.source for scenario in scenarios} | {scenario.target for scenario in scenarios}),
        "beast_semantic_correct": system_scores["beast_c4x"]["semantic_correct"],
        "beast_artifact_custody_valid": system_scores["beast_c4x"]["artifact_custody_valid"],
        "beast_honest_uncertainty": system_scores["beast_c4x"]["honest_uncertainty"],
        "beast_provider_calls_used": system_scores["beast_c4x"]["provider_calls_used"],
        "baseline_count": len(BASELINES),
        "beast_beats_all_reference_baselines": all(
            system_scores["beast_c4x"]["total_score"] > system_scores[name]["total_score"]
            for name in BASELINES
        ),
        "breakthrough_protocol_pass": breakthrough_pass,
    }
    report_core = {
        "beast_object_type": "c4x_external_breakthrough_benchmark",
        "version": "1.0",
        "run_id": run_id or utc_now_iso().replace(":", "").replace("+", "z"),
        "observed_at": utc_now_iso(),
        "claim_boundary": (
            "Reference external-breakthrough benchmark scaffold. Held-out cases are generated after engine "
            "freeze from an evaluator seed. Baseline adapters are transparent local references and should be "
            "replaced by independent public implementations for third-party claims."
        ),
        "scorecard": scorecard,
        "systems": system_scores,
        "baseline_adapters": {name: _baseline_description(name) for name in BASELINES},
        "cases": cases,
    }
    report = {**report_core, "receipt_digest": sha256_digest(report_core)}
    root = Path(evidence_root)
    run_root = root / report["run_id"]
    run_root.mkdir(parents=True, exist_ok=True)
    (run_root / "benchmark.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (run_root / "benchmark.md").write_text(_markdown(report), encoding="utf-8")
    _write_checksums(run_root)
    root.mkdir(parents=True, exist_ok=True)
    (root / "latest.json").write_text(json.dumps(report, sort_keys=True, indent=2) + "\n", encoding="utf-8")
    (root / "latest.md").write_text(_markdown(report), encoding="utf-8")
    return {**report, "evidence_root": str(run_root)}


def generate_heldout_scenarios(
    *,
    evaluator_seed: str,
    engine_freeze_digest: str,
    case_count_per_family: int,
) -> tuple[Scenario, ...]:
    rng = random.Random(sha256_digest({"seed": evaluator_seed, "engine": engine_freeze_digest}))
    families = (Family.RESTART_RISK, Family.TRAFFIC_SHIFT, Family.DEPLOYMENT_SAFETY)
    scenarios = []
    for family in families:
        for index in range(case_count_per_family):
            scenarios.append(_random_scenario(rng, family, index))
    return tuple(scenarios)


def _random_scenario(rng: random.Random, family: Family, index: int) -> Scenario:
    source = _service_name(rng)
    target = _service_name(rng, avoid={source})
    stale = rng.random() < 0.2
    missing_rule = rng.random() < 0.15
    missing_asset = rng.random() < 0.15
    overflow = rng.random() < 0.1
    assets = default_visual_assets()
    if missing_asset:
        assets = {key: value for key, value in assets.items() if key != f"{family.value}:status_badge"}
    if family is Family.RESTART_RISK:
        healthy = rng.random() >= 0.25
        facts = (
            make_fact("service_health", source, "health", {"state": "healthy" if healthy else "degraded"}),
            make_fact("service_health", target, "health", {"state": "healthy"}),
            make_fact("dependency_topology", target, "depends_on", {"relation": "depends_on"}, object=source),
            make_fact("restart_policy", source, "restart_policy", {"mode": rng.choice(("rolling_with_healthcheck", "blue_green", "immediate"))}),
            make_fact("current_evidence", "runtime", "current_evidence", {"state": "fresh", "restart_count": rng.randint(0, 3)}),
        )
        rules = () if missing_rule else (make_rule(family, "restart_destabilization"),)
        policies = (make_policy(family, {"allowed_mode": "rolling_with_healthcheck"}),)
        question = f"Could restarting {source} destabilize {target}? Render the dependency/risk path."
    elif family is Family.TRAFFIC_SHIFT:
        shift = rng.choice((10, 15, 20, 30, 40))
        target_spare = rng.choice((12, 18, 25, 35, 55, 70))
        facts = (
            make_fact("capacity_state", source, "capacity", {"load_percent": rng.randint(20, 90), "spare_percent": rng.randint(10, 80)}),
            make_fact("capacity_state", target, "capacity", {"load_percent": max(0, 100 - target_spare), "spare_percent": target_spare}),
            make_fact("traffic_route", source, "routes_to", {"state": rng.choice(("healthy", "healthy", "degraded"))}, object=target),
            make_fact("current_evidence", "runtime", "current_evidence", {"state": "fresh"}),
        )
        rules = () if missing_rule else (make_rule(family, "traffic_shift_capacity"),)
        policies = (make_policy(family, {"minimum_reserve_percent": rng.choice((10, 15, 20))}),)
        question = f"Can {shift}% traffic shift from {source} to {target}? Render capacity and route state."
        metadata = {"shift_percent": shift}
        return Scenario(
            scenario_id=f"heldout-{family.value}-{index}-{source.lower()}-{target.lower()}",
            family=family,
            question=question,
            source=source,
            target=target,
            facts=facts,
            rules=rules,
            policies=policies,
            visual_assets=assets,
            force_layout_overflow=overflow,
            metadata={**metadata, **({"temporal_state": "stale"} if stale else {})},
        )
    else:
        gate_passed = rng.random() >= 0.25
        error_rate = round(rng.uniform(0.1, 4.0), 2)
        facts = (
            make_fact("deployment_stage", source, "stage", {"stage": rng.choice(("canary_10", "canary_25", "regional_50"))}),
            make_fact("health_gate", source, "health_gate", {"passed": gate_passed, "error_rate_percent": error_rate}),
            make_fact("rollback_state", source, "rollback", {"ready": rng.random() >= 0.1}),
            make_fact("service_health", target, "health", {"state": rng.choice(("healthy", "healthy", "degraded"))}),
            make_fact("current_evidence", "runtime", "current_evidence", {"state": "fresh"}),
        )
        rules = () if missing_rule else (make_rule(family, "deployment_rollout_safety"),)
        policies = (make_policy(family, {"max_error_rate_percent": rng.choice((0.8, 1.0, 1.5))}),)
        question = f"Should deployment from {source} continue toward {target}? Render gates and rollback."
    return Scenario(
        scenario_id=f"heldout-{family.value}-{index}-{source.lower()}-{target.lower()}",
        family=family,
        question=question,
        source=source,
        target=target,
        facts=facts,
        rules=rules,
        policies=policies,
        visual_assets=assets,
        force_layout_overflow=overflow,
        metadata={"temporal_state": "stale"} if stale else {},
    )


def _baseline_output(name: str, scenario: Scenario) -> dict[str, Any]:
    if name == "cached_named_template":
        known = scenario.source in {"BEAST", "Aegis", "Commons"} or scenario.target in {"BEAST", "Aegis", "Commons"}
        return {
            "system_id": name,
            "answer_text": f"Cached template says {scenario.source} to {scenario.target} is safe." if known else "No cached template.",
            "visual_bytes": b"",
            "status": "composed" if known else "refused",
            "current_claim_valid": known,
            "provider_calls_used": 0,
            "artifact_custody_valid": False,
            "proof_first": False,
        }
    if name == "rag_nearest_exemplar":
        exemplar = {
            Family.RESTART_RISK: "Restarting BEAST has low demonstrated risk for Commons.",
            Family.TRAFFIC_SHIFT: "Shifting 30% traffic from Aegis to Commons is safe.",
            Family.DEPLOYMENT_SAFETY: "The BEAST rollout is safe to continue toward Commons.",
        }[scenario.family]
        return {
            "system_id": name,
            "answer_text": exemplar,
            "visual_bytes": b"<svg><!-- retrieved exemplar diagram --></svg>",
            "status": "composed",
            "current_claim_valid": True,
            "provider_calls_used": 0,
            "artifact_custody_valid": False,
            "proof_first": False,
        }
    if name == "rule_engine_text_only":
        return {
            "system_id": name,
            "answer_text": _rule_engine_answer(scenario),
            "visual_bytes": b"",
            "status": "composed",
            "current_claim_valid": "cannot establish" not in _rule_engine_answer(scenario),
            "provider_calls_used": 0,
            "artifact_custody_valid": False,
            "proof_first": False,
        }
    if name == "knowledge_graph_topology_only":
        return {
            "system_id": name,
            "answer_text": f"Topology connects {scenario.source} and {scenario.target}; relationship appears reachable.",
            "visual_bytes": b"<svg><!-- topology only --></svg>",
            "status": "composed",
            "current_claim_valid": True,
            "provider_calls_used": 0,
            "artifact_custody_valid": False,
            "proof_first": False,
        }
    return {
        "system_id": name,
        "answer_text": f"Model answer: {scenario.source} and {scenario.target} look operationally safe with a nice diagram.",
        "visual_bytes": b"<svg><!-- model generated unverified multimodal answer --></svg>",
        "status": "composed",
        "current_claim_valid": True,
        "provider_calls_used": 2,
        "artifact_custody_valid": False,
        "proof_first": False,
    }


def _rule_engine_answer(scenario: Scenario) -> str:
    if scenario.metadata.get("temporal_state") == "stale":
        return f"Rule engine cannot establish current state for {scenario.source}->{scenario.target}."
    if not scenario.rules:
        return f"Rule engine cannot establish missing rule for {scenario.source}->{scenario.target}."
    if scenario.family is Family.TRAFFIC_SHIFT:
        target = next(f for f in scenario.facts if f.fact_type == "capacity_state" and f.subject == scenario.target)
        spare = float(target.value["spare_percent"])
        shift = float(scenario.metadata.get("shift_percent", 0))
        reserve = float(scenario.policies[0].parameters["minimum_reserve_percent"])
        return f"Traffic shift is {'safe' if spare >= shift + reserve else 'unsafe'}."
    if scenario.family is Family.DEPLOYMENT_SAFETY:
        gate = next(f for f in scenario.facts if f.fact_type == "health_gate")
        return "Deployment should continue." if gate.value.get("passed") else "Deployment should halt or rollback."
    return f"Restart risk for {scenario.source}->{scenario.target} is bounded by policy."


def _evaluate_output(expected: Mapping[str, Any], output: Mapping[str, Any]) -> dict[str, Any]:
    text = str(output.get("answer_text") or "").casefold()
    artifact_custody_valid = output.get("artifact_custody_valid") is True
    if output.get("joined_verification") is True and artifact_custody_valid and output.get("proof_first") is True:
        semantic_correct = True
        honest_uncertainty = (
            output.get("current_claim_valid") is False
            if not expected["current_claim_allowed"]
            else output.get("current_claim_valid") is True
        )
        visual_present = bool(output.get("visual_bytes"))
        return {
            "system_id": str(output.get("system_id") or ""),
            "semantic_correct": semantic_correct,
            "honest_uncertainty": honest_uncertainty,
            "visual_present": visual_present,
            "artifact_custody_valid": artifact_custody_valid,
            "proof_first": True,
            "provider_calls_used": int(output.get("provider_calls_used") or 0),
            "total_score": (
                int(semantic_correct) * 4
                + int(honest_uncertainty) * 3
                + int(visual_present) * 1
                + int(artifact_custody_valid) * 5
                + 3
                - int(output.get("provider_calls_used") or 0)
            ),
        }
    expected_class = str(expected["class"]).casefold()
    source = str(expected["source"]).casefold()
    target = str(expected["target"]).casefold()
    semantic_correct = (
        source in text
        and target in text
        and (
            expected_class in text
            or (expected["status"] == "stale" and "cannot establish" in text)
            or (expected["status"] == "residual_required" and "missing rule" in text)
            or (expected["status"] == "unsupported" and "cannot establish" in text)
        )
    )
    honest_uncertainty = True
    if expected["status"] in {"stale", "residual_required", "unsupported"} or not expected["current_claim_allowed"]:
        honest_uncertainty = output.get("current_claim_valid") is False or "cannot" in text or "missing" in text or "refuse" in text
    visual_present = bool(output.get("visual_bytes"))
    return {
        "system_id": str(output.get("system_id") or ""),
        "semantic_correct": semantic_correct,
        "honest_uncertainty": honest_uncertainty,
        "visual_present": visual_present,
        "artifact_custody_valid": artifact_custody_valid,
        "proof_first": output.get("proof_first") is True,
        "provider_calls_used": int(output.get("provider_calls_used") or 0),
        "total_score": (
            int(semantic_correct) * 4
            + int(honest_uncertainty) * 3
            + int(visual_present) * 1
            + int(artifact_custody_valid) * 5
            + int(output.get("proof_first") is True) * 3
            - int(output.get("provider_calls_used") or 0)
        ),
    }


def _expected_from_beast(result: Any) -> dict[str, Any]:
    conclusion = result.proof_graph.conclusion_claim
    family = result.scenario.family
    if family is Family.RESTART_RISK:
        klass = str(conclusion.metadata.get("risk_class") or conclusion.status.value)
    elif family is Family.TRAFFIC_SHIFT:
        klass = str(conclusion.metadata.get("shift_class") or conclusion.status.value)
    else:
        klass = str(conclusion.metadata.get("deployment_class") or conclusion.status.value)
    return {
        "family": family.value,
        "source": result.scenario.source,
        "target": result.scenario.target,
        "status": conclusion.status.value,
        "class": klass,
        "current_claim_allowed": conclusion.current_claim_allowed,
        "joined_status": result.joined_receipt["status"],
    }


def _empty_baseline_score() -> dict[str, int]:
    return {
        "semantic_correct": 0,
        "honest_uncertainty": 0,
        "visual_present": 0,
        "artifact_custody_valid": 0,
        "proof_first": 0,
        "provider_calls_used": 0,
        "total_score": 0,
    }


def _accumulate(score: dict[str, int], evaluated: Mapping[str, Any]) -> None:
    for key in ("semantic_correct", "honest_uncertainty", "visual_present", "artifact_custody_valid", "proof_first"):
        score[key] += int(evaluated.get(key) is True)
    score["provider_calls_used"] += int(evaluated.get("provider_calls_used") or 0)
    score["total_score"] += int(evaluated.get("total_score") or 0)


def _finalize_score(score: Mapping[str, int], total_cases: int) -> dict[str, Any]:
    return {
        **dict(score),
        "case_count": total_cases,
        "semantic_accuracy": round(score["semantic_correct"] / max(1, total_cases), 6),
    }


def _service_name(rng: random.Random, *, avoid: set[str] | None = None) -> str:
    avoid = avoid or set()
    syllables = ("Ari", "Bex", "Cyra", "Dune", "Eko", "Flux", "Gale", "Halo", "Ion", "Juno", "Kite", "Luma", "Mira", "Nox", "Orin", "Pax", "Quill", "Riven", "Sora", "Talon", "Uma", "Vega", "Wisp", "Yara", "Zeno")
    while True:
        name = rng.choice(syllables) + "-" + rng.choice(("api", "edge", "core", "mesh", "worker", "canary"))
        if name not in avoid:
            return name


def _scenario_public(scenario: Scenario) -> dict[str, Any]:
    return {
        "scenario_id": scenario.scenario_id,
        "family": scenario.family.value,
        "question": scenario.question,
        "source": scenario.source,
        "target": scenario.target,
        "fact_count": len(scenario.facts),
        "rule_count": len(scenario.rules),
        "policy_count": len(scenario.policies),
        "metadata": dict(scenario.metadata),
        "force_layout_overflow": scenario.force_layout_overflow,
        "scenario_digest": sha256_digest(asdict(scenario)),
    }


def _baseline_description(name: str) -> str:
    return {
        "rag_nearest_exemplar": "Retrieves a nearest named exemplar answer/diagram without proof custody.",
        "cached_named_template": "Replays only named-scenario templates; held-out names miss.",
        "rule_engine_text_only": "Computes text from rules but emits no proof-bound visual artifact.",
        "knowledge_graph_topology_only": "Uses topology reachability and ignores policy/temporal/capacity gates.",
        "model_generated_multimodal_stub": "Simulates provider multimodal answer with unverified text/SVG and provider cost.",
    }[name]


def _write_checksums(root: Path) -> None:
    rows = []
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.name != "SHA256SUMS.txt":
            rows.append(f"{hashlib.sha256(path.read_bytes()).hexdigest()}  {path.relative_to(root)}")
    (root / "SHA256SUMS.txt").write_text("\n".join(rows) + "\n", encoding="utf-8")


def _markdown(report: Mapping[str, Any]) -> str:
    score = report["scorecard"]
    systems = report["systems"]
    lines = [
        f"# C4-X external breakthrough benchmark · {report['run_id']}",
        "",
        f"- Receipt: `{report['receipt_digest']}`",
        f"- Engine freeze digest: `{score['engine_freeze_digest']}`",
        f"- Evaluator seed: `{score['evaluator_seed']}`",
        f"- Held-out cases: `{score['heldout_cases']}`",
        f"- Cross-modal families: `{score['cross_modal_families']}`",
        f"- Randomized service names: `{score['randomized_service_names']}`",
        f"- BEAST semantic correct: `{score['beast_semantic_correct']}/{score['heldout_cases']}`",
        f"- BEAST artifact custody valid: `{score['beast_artifact_custody_valid']}/{score['heldout_cases']}`",
        f"- BEAST provider calls used: `{score['beast_provider_calls_used']}`",
        f"- Baselines compared: `{score['baseline_count']}`",
        f"- BEAST beats all reference baselines: `{score['beast_beats_all_reference_baselines']}`",
        f"- Breakthrough protocol pass: `{score['breakthrough_protocol_pass']}`",
        "",
        "## System scores",
        "",
    ]
    for name, values in systems.items():
        lines.append(
            f"- `{name}`: total={values['total_score']}, semantic={values['semantic_correct']}/{values['case_count']}, "
            f"custody={values['artifact_custody_valid']}/{values['case_count']}, providers={values['provider_calls_used']}"
        )
    lines.extend(["", "## Boundary", "", str(report["claim_boundary"]), ""])
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evaluator-seed", required=True, help="Seed supplied after engine freeze by evaluator/third party.")
    parser.add_argument("--case-count-per-family", type=int, default=4)
    parser.add_argument("--evidence-root", default=str(REPO_ROOT / "evidence" / "c4x-external-breakthrough-benchmark"))
    parser.add_argument("--run-id", default=None)
    args = parser.parse_args(argv)
    report = run_breakthrough_benchmark(
        evaluator_seed=args.evaluator_seed,
        case_count_per_family=args.case_count_per_family,
        evidence_root=args.evidence_root,
        run_id=args.run_id,
    )
    print(json.dumps({
        "receipt_digest": report["receipt_digest"],
        "breakthrough_protocol_pass": report["scorecard"]["breakthrough_protocol_pass"],
        "scorecard": report["scorecard"],
        "evidence_root": report["evidence_root"],
    }, sort_keys=True, indent=2))
    return 0 if report["scorecard"]["breakthrough_protocol_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
