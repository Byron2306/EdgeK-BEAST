from pathlib import Path

from scripts.run_c4x_external_breakthrough_benchmark import (
    BASELINES,
    generate_heldout_scenarios,
    run_breakthrough_benchmark,
)


def test_heldout_generator_uses_post_freeze_seed_and_randomized_names():
    first = generate_heldout_scenarios(
        evaluator_seed="outside-seed-a",
        engine_freeze_digest="sha256:" + "a" * 64,
        case_count_per_family=2,
    )
    second = generate_heldout_scenarios(
        evaluator_seed="outside-seed-b",
        engine_freeze_digest="sha256:" + "a" * 64,
        case_count_per_family=2,
    )

    assert len(first) == 6
    assert {scenario.family.value for scenario in first} == {"restart_risk", "traffic_shift", "deployment_safety"}
    assert {scenario.scenario_id for scenario in first} != {scenario.scenario_id for scenario in second}
    assert not {"BEAST", "Commons", "Aegis"} & {scenario.source for scenario in first}


def test_external_breakthrough_benchmark_compares_baselines_and_writes_receipts(tmp_path: Path):
    report = run_breakthrough_benchmark(
        evaluator_seed="pytest-external-breakthrough",
        case_count_per_family=2,
        evidence_root=tmp_path,
        run_id="pytest-breakthrough",
    )

    assert report["scorecard"]["breakthrough_protocol_pass"] is True
    assert report["scorecard"]["heldout_cases"] == 6
    assert report["scorecard"]["cross_modal_families"] == 3
    assert report["scorecard"]["beast_semantic_correct"] == 6
    assert report["scorecard"]["beast_artifact_custody_valid"] == 6
    assert report["scorecard"]["beast_provider_calls_used"] == 0
    assert set(BASELINES).issubset(report["systems"])
    assert report["systems"]["beast_c4x"]["total_score"] > max(
        report["systems"][baseline]["total_score"] for baseline in BASELINES
    )
    assert (tmp_path / "pytest-breakthrough" / "benchmark.json").is_file()
    assert (tmp_path / "pytest-breakthrough" / "SHA256SUMS.txt").is_file()
