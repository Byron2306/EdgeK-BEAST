# BEAST C4-X Truth Arena Full Snapshot

Includes the full Truth Arena snapshot with:

- Truth scoreboard
- KV War / Forge KV sidecars
- RAG War sidecars
- Provider evidence sidecars
- Live Aurora RDS RAG evidence
- Focused tests and plan update

No `.beast` env files, API keys, DSNs, IAM tokens, passwords, or provider secrets are included.

Key receipt: `sha256:a1e80850606cc0154c7e5d093e4f91908f0deee827e8ea89fcc0fdfb25a3bd64`

RAG War highlight:

- Aurora pgvector corpus-poor: 0/12 semantic, 0 retrieved cases.
- Aurora pgvector seeded: 12/12 semantic, 12 retrieved cases.
- Seeded pgvector proof-first: 0.
- Seeded pgvector artifact custody: 0.

BEAST remains truth/custody winner in the included run.
