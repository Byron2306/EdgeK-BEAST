# Commons ML-KEM gauntlet — self-contained-full-12-gate-smoke-commons-ml-kem

- Status: `passed`
- Receipt digest: `sha256:9ff3b1cf630d1457caf0e25be6526792f7154d0b08ca8e9f100f4b0bf4800fe1`
- Algorithm: `ML-KEM-768`
- Nodes confirmed: 3 / 3
- Pairwise transcript edges: 6
- Secret policy: `shared_secret_bytes_never_serialized`

## commons-node-a

- Base URL: `http://127.0.0.1:8111`
- Public key digest: `sha256:d919e1edec7a5a683871de1b88d558225e01296b11f94301f96d59348267d132`
- Ciphertext digest: `sha256:2eb0212a647c467c13bb2b4246c38c8df24904bbf12b440487c3d02fee32dd91`
- Confirmation digest: `sha256:c7b9c1b37ac7fe8ee0aad5ceb5148452ea673b6b14d6a89ac464f0682fe0186e`
- Confirmed: `True`

## commons-node-b

- Base URL: `http://127.0.0.1:8112`
- Public key digest: `sha256:bb292473e2e0047b50889da9ea3c26a20c3e0f62c355333656d584e7f208fbe8`
- Ciphertext digest: `sha256:8abf48195dc15d63001881c3ba5156c8cdeba3048c2ee479d5ea8c17f1e2f3d7`
- Confirmation digest: `sha256:e3694fb61b17821c2a40102477b8e541301029981f5e7686a713080d454ffe85`
- Confirmed: `True`

## commons-node-c

- Base URL: `http://127.0.0.1:8113`
- Public key digest: `sha256:90c231f5bb9b03d912e8895899a50b9651534b49b2f45666d021d90db650802e`
- Ciphertext digest: `sha256:1e253bf0ffc1810e195d9e31b4a1201412c4d95caa0c6333a4ec9573c0876b78`
- Confirmation digest: `sha256:3252a0e10335839c63abcdf5cb7b186b73dc84319aa58a3d6625ab47936df58c`
- Confirmed: `True`
