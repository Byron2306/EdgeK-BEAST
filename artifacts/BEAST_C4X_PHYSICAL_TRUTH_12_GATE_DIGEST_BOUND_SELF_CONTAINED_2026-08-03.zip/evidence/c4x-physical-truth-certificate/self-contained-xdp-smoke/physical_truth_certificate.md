# C4-X physical truth certificate · self-contained-xdp-smoke

- Receipt: `sha256:da89ecfc33a5c1dd2f6396b293078a45b1175cc7385231e942a7f542ad7230d2`
- Public credit allowed: `True`
- Truth claim allowed: `True`
- Critical failures: `0`

## Certificate gates

- `c4x_truth`: `True`
- `sensorium_observation`: `True`
- `bpf_witness`: `True`
- `protocol_integrity`: `True`
- `memfd_custody`: `True`
- `guardian_custody`: `True`
- `reuse`: `True`
- `pq_transport`: `True`
- `commons_replication`: `True`
- `route_resilience`: `True`
- `psi_governance`: `True`
- `xdp_scope`: `True`

## Boundary

Final BEAST physical-truth claim. C4-X semantic proof, Sensorium/BPF observation, Crystal Bus protocol integrity, memfd/Guardian custody, reuse, post-quantum transport, Commons replication, route resilience, PSI governance, and scoped XDP must all pass independently. Missing or partial evidence lowers authority instead of being averaged away.
