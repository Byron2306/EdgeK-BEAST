# C4-X physical truth certificate · self-contained-full-12-gate-smoke-xdp-scope

- Receipt: `sha256:9c8e80e8671c620f88398d9ff14f0c65b9ba4b72f91db667a7caf06e72f1f5b6`
- Public credit allowed: `True`
- Truth claim allowed: `True`
- Critical failures: `0`

## Certificate gates

- `c4x_truth`: `True`
- `sensorium_observation`: `True`
- `bpf_witness`: `True`
- `protocol_integrity`: `True`
- `memfd_custody`: `True`
- `guardian_custody`: `True`
- `reuse`: `True`
- `pq_transport`: `True`
- `commons_replication`: `True`
- `route_resilience`: `True`
- `psi_governance`: `True`
- `xdp_scope`: `True`

## Boundary

Final BEAST physical-truth claim. C4-X semantic proof, Sensorium/BPF observation, Crystal Bus protocol integrity, memfd/Guardian custody, reuse, post-quantum transport, Commons replication, route resilience, PSI governance, and scoped XDP must all pass independently. Missing or partial evidence lowers authority instead of being averaged away.
