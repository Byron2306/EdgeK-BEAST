# C4-X physical truth certificate · self-contained-full-12-gate-smoke-sensorium-bpf

- Receipt: `sha256:0d0bf0731bba553cec5ac0bd1e02a5fcd198c3ba0acbeda3b927dc190dfc24cb`
- Public credit allowed: `True`
- Truth claim allowed: `True`
- Critical failures: `0`

## Certificate gates

- `c4x_truth`: `True`
- `sensorium_observation`: `True`
- `bpf_witness`: `True`
- `protocol_integrity`: `True`
- `memfd_custody`: `True`
- `guardian_custody`: `True`
- `reuse`: `True`
- `pq_transport`: `True`
- `commons_replication`: `True`
- `route_resilience`: `True`
- `psi_governance`: `True`
- `xdp_scope`: `True`

## Boundary

Final BEAST physical-truth claim. C4-X semantic proof, Sensorium/BPF observation, Crystal Bus protocol integrity, memfd/Guardian custody, reuse, post-quantum transport, Commons replication, route resilience, PSI governance, and scoped XDP must all pass independently. Missing or partial evidence lowers authority instead of being averaged away.
