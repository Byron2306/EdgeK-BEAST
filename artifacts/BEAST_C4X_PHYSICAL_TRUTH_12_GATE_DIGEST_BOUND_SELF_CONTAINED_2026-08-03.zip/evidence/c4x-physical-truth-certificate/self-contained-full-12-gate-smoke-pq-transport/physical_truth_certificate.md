# C4-X physical truth certificate · self-contained-full-12-gate-smoke-pq-transport

- Receipt: `sha256:15d5a5694d0eab4935c27c042bd3bcfd156cb60aca217d3d4037341a06fc5db0`
- Public credit allowed: `True`
- Truth claim allowed: `True`
- Critical failures: `0`

## Certificate gates

- `c4x_truth`: `True`
- `sensorium_observation`: `True`
- `bpf_witness`: `True`
- `protocol_integrity`: `True`
- `memfd_custody`: `True`
- `guardian_custody`: `True`
- `reuse`: `True`
- `pq_transport`: `True`
- `commons_replication`: `True`
- `route_resilience`: `True`
- `psi_governance`: `True`
- `xdp_scope`: `True`

## Boundary

Final BEAST physical-truth claim. C4-X semantic proof, Sensorium/BPF observation, Crystal Bus protocol integrity, memfd/Guardian custody, reuse, post-quantum transport, Commons replication, route resilience, PSI governance, and scoped XDP must all pass independently. Missing or partial evidence lowers authority instead of being averaged away.
