"""Explicit, capability-like TCP port leases for governed services."""
from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
import json
import socket
import threading
import time
from typing import Callable, Dict
from pathlib import Path


from enum import Enum, auto

class LifecycleState(Enum):
    RESERVED = auto()
    HANDED_OFF = auto()
    ACTIVE = auto()
    RELEASED = auto()

class HealthState(Enum):
    UNKNOWN = auto()
    HEALTHY = auto()
    UNHEALTHY = auto()

@dataclass(frozen=True)
class PortLease:
    lease_id: str
    service_id: str
    workspace_id: str
    host: str
    port: int
    protocol: str
    issued_at_monotonic_ns: int
    receipt_digest: str
    network_namespace: str = "host"
    listener_generation: int = 1
    expires_at_monotonic_ns: int = 0
    family: str = "AF_INET"
    vrf: str = "production"
    lifecycle_state: LifecycleState = LifecycleState.RESERVED
    health_state: HealthState = HealthState.UNKNOWN
    authority_ref: str = ""
    appraisal_ref: str = ""
    transferred_at_monotonic_ns: int = 0
    capability_ref: str = ""
    policy_generation: str = ""
    registry_digest: str = ""
    issued_at_unix: float = 0.0
    expires_at_unix: float = 0.0
    release_reason: str = ""


@dataclass(frozen=True)
class SocketHandoffReceipt:
    lease_id: str
    service_id: str
    workspace_id: str
    listener_generation: int
    network_namespace: str
    vrf: str
    authority_ref: str
    appraisal_ref: str
    transferred_at_monotonic_ns: int
    receipt_digest: str
    capability_ref: str = ""
    policy_generation: str = ""
    registry_digest: str = ""
    guardian_id: str = "beast.local/in-process-broker"
    signature: str = ""


class PortLeaseBroker:
    """Reserve ports by retaining the bound socket until explicit release.

    A service receives a receipt and must use the returned socket (or release
    the lease before binding independently). Silent port seizure is impossible
    while the broker owns the reservation.
    """

    def __init__(self, *, socket_factory: Callable[..., socket.socket] = socket.socket,
                 guardian_client=None, max_active_leases: int = 128) -> None:
        self._lock = threading.RLock()
        self._leases: Dict[str, tuple[PortLease, socket.socket, bool]] = {}
        self._socket_factory = socket_factory
        self._generations: Dict[tuple[str, str, str, int, str], int] = {}
        self._flap_history: Dict[str, list[int]] = {}
        self.guardian_client = guardian_client
        self.max_active_leases = max(1, int(max_active_leases))

    def _reap_expired_locked(self, now: int) -> None:
        """Close expired descriptors even when no explicit reconcile runs."""
        expired = [
            lease_id for lease_id, (lease, _sock, _transferred) in self._leases.items()
            if lease.expires_at_monotonic_ns and now >= lease.expires_at_monotonic_ns
        ]
        for lease_id in expired:
            _lease, sock, _transferred = self._leases.pop(lease_id)
            try:
                sock.close()
            except OSError:
                pass

    def reserve(self, service_id: str, workspace_id: str, *, host: str = "127.0.0.1",
                port: int = 0, network_namespace: str = "host", ttl_seconds: float = 0,
                family: str = "AF_INET", protocol: str = "TCP", vrf: str = "production",
                authority_ref: str = "", appraisal_ref: str = "", capability_ref: str = "",
                policy_generation: str = "", registry_digest: str = "") -> PortLease:
        if self.guardian_client is not None:
            return self.guardian_client.reserve(
                service_id, workspace_id, host=host, port=port,
                network_namespace=network_namespace, ttl_seconds=ttl_seconds,
                family=family, protocol=protocol, vrf=vrf,
                authority_ref=authority_ref, appraisal_ref=appraisal_ref,
                capability_ref=capability_ref, policy_generation=policy_generation,
                registry_digest=registry_digest,
            )
        if not service_id or not workspace_id:
            raise ValueError("service_id and workspace_id are required")
        if not 0 <= port <= 65535:
            raise ValueError("port must be between 0 and 65535")
            
        issued = time.monotonic_ns()
        with self._lock:
            self._reap_expired_locked(issued)
            if len(self._leases) >= self.max_active_leases:
                raise RuntimeError("port lease capacity exhausted")
            history = self._flap_history.setdefault(service_id, [])
            cutoff = issued - 60_000_000_000  # 60s sliding window
            history = [t for t in history if t > cutoff]
            self._flap_history[service_id] = history
            if len(history) >= 10:
                raise PermissionError(f"Route flapping detected: Service {service_id} requested too many leases within 60s")
            history.append(issued)

        if family not in {"AF_INET", "AF_INET6"}:
            raise ValueError("family must be AF_INET or AF_INET6")
        protocol = protocol.upper()
        if protocol not in {"TCP", "UDP"}:
            raise ValueError("protocol must be TCP or UDP")
        socket_family = socket.AF_INET if family == "AF_INET" else socket.AF_INET6
        socket_type = socket.SOCK_STREAM if protocol == "TCP" else socket.SOCK_DGRAM
        sock = self._socket_factory(socket_family, socket_type)
        try:
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            # Enable SO_REUSEPORT to allow multiple processes/threads to bind to the same port
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            sock.bind((host, port))
            actual_port = int(sock.getsockname()[1])
            generation_key = (family, protocol, host, actual_port, network_namespace)
            with self._lock:
                generation = self._generations.get(generation_key, 0) + 1
                self._generations[generation_key] = generation
            material = {"service_id": service_id, "workspace_id": workspace_id,
                        "host": host, "port": actual_port, "protocol": protocol,
                        "family": family, "network_namespace": network_namespace,
                        "vrf": vrf, "listener_generation": generation,
                        "authority_ref": authority_ref, "appraisal_ref": appraisal_ref,
                        "capability_ref": capability_ref, "policy_generation": policy_generation,
                        "registry_digest": registry_digest,
                        "issued_at_monotonic_ns": issued}
            lease_id = "portlease:" + hashlib.sha256(
                json.dumps(material, sort_keys=True, separators=(",", ":")).encode()
            ).hexdigest()
            digest = "sha256:" + hashlib.sha256(lease_id.encode()).hexdigest()
            expiry = issued + int(ttl_seconds * 1_000_000_000) if ttl_seconds else 0
            lease = PortLease(
                lease_id, service_id, workspace_id, host, actual_port, protocol,
                issued, digest, network_namespace, generation, expiry, family, vrf,
                "reserved", "unknown", authority_ref, appraisal_ref, 0,
                capability_ref, policy_generation, registry_digest, time.time(),
                time.time() + ttl_seconds if ttl_seconds else 0.0, "",
            )
            with self._lock:
                self._leases[lease_id] = (lease, sock, False)
            return lease
        except Exception:
            sock.close()
            raise

    def take_socket_with_receipt(self, lease_id: str, *, workspace_id: str = "",
                                 capability_ref: str = "", appraisal_ref: str = "",
                                 policy_generation: str = "", registry_digest: str = "") -> tuple[socket.socket, SocketHandoffReceipt]:
        if self.guardian_client is not None:
            _lease, sock, receipt = self.guardian_client.recover(
                lease_id, workspace_id=workspace_id, capability_ref=capability_ref,
                appraisal_ref=appraisal_ref, policy_generation=policy_generation,
                registry_digest=registry_digest,
            )
            return sock, receipt
        with self._lock:
            try:
                lease, sock, _ = self._leases[lease_id]
                if lease.expires_at_monotonic_ns and time.monotonic_ns() >= lease.expires_at_monotonic_ns:
                    raise KeyError("expired port lease")
                
                # Strict transition check
                if lease.lifecycle_state != LifecycleState.RESERVED:
                    raise ValueError(f"Invalid transition from {lease.lifecycle_state} to HANDED_OFF")
                
                # Binding and Authorization Enforcement
                if workspace_id and lease.workspace_id != workspace_id:
                    raise PermissionError(f"Workspace mismatch: {workspace_id} vs {lease.workspace_id}")
                if capability_ref and lease.capability_ref != capability_ref:
                    raise PermissionError("Capability reference mismatch")
                if registry_digest and lease.registry_digest != registry_digest:
                    raise PermissionError("Registry reconciliation failed")

                transferred_at = time.monotonic_ns()
                lease = replace(lease, lifecycle_state=LifecycleState.HANDED_OFF, 
                                transferred_at_monotonic_ns=transferred_at,
                                capability_ref=capability_ref or lease.capability_ref,
                                appraisal_ref=appraisal_ref or lease.appraisal_ref)
                self._leases[lease_id] = (lease, sock, True)
                
                material = {
                    "lease_id": lease.lease_id, "service_id": lease.service_id,
                    "workspace_id": lease.workspace_id,
                    "listener_generation": lease.listener_generation,
                    "network_namespace": lease.network_namespace, "vrf": lease.vrf,
                    "authority_ref": lease.authority_ref, "appraisal_ref": lease.appraisal_ref,
                    "capability_ref": lease.capability_ref, "policy_generation": lease.policy_generation,
                    "registry_digest": lease.registry_digest,
                    "transferred_at_monotonic_ns": transferred_at,
                }
                
                digest = "sha256:" + hashlib.sha256(
                    json.dumps(material, sort_keys=True, separators=(",", ":")).encode()
                ).hexdigest()
                receipt = SocketHandoffReceipt(**material, receipt_digest=digest)
                return sock, receipt
            except KeyError as exc:
                raise KeyError("unknown or released port lease") from exc

    def take_socket(self, lease_id: str, **binding) -> socket.socket:
        """Compatibility wrapper; governed callers should retain the receipt."""
        return self.take_socket_with_receipt(lease_id, **binding)[0]

    def release(self, lease_id: str, **binding) -> PortLease:
        if self.guardian_client is not None:
            return self.guardian_client.release(lease_id, **binding)
        with self._lock:
            try:
                lease, sock, _ = self._leases.pop(lease_id)
            except KeyError as exc:
                raise KeyError("unknown or released port lease") from exc
            sock.close()
            return replace(lease, lifecycle_state="released", release_reason=str(binding.get("reason") or "explicit_release"))

    def mark_health(self, lease_id: str, *, healthy: bool, **binding) -> PortLease:
        if self.guardian_client is not None:
            return self.guardian_client.mark_health(lease_id, healthy=healthy, **binding)
        with self._lock:
            try:
                lease, sock, transferred = self._leases[lease_id]
            except KeyError as exc:
                raise KeyError("unknown or released port lease") from exc
            lease = replace(lease, health_state=HealthState.HEALTHY if healthy else HealthState.UNHEALTHY)
            self._leases[lease_id] = (lease, sock, transferred)
            return lease

    @staticmethod
    def reconciliation_key(lease: PortLease, *, local_address_class: str) -> tuple[object, ...]:
        return (
            lease.family, lease.protocol, local_address_class, lease.port,
            lease.workspace_id, lease.service_id, lease.listener_generation,
            lease.network_namespace, lease.vrf,
        )

    def snapshot(self) -> tuple[PortLease, ...]:
        if self.guardian_client is not None:
            return self.guardian_client.snapshot()
        with self._lock:
            self._reap_expired_locked(time.monotonic_ns())
            return tuple(item[0] for item in self._leases.values() if not item[0].expires_at_monotonic_ns or time.monotonic_ns() < item[0].expires_at_monotonic_ns)

    def reconcile(self, *, now_monotonic_ns: int | None = None, registry_digest: str | None = None, **binding) -> tuple[PortLease, ...]:
        """Expire leases, validate persistent state, and enforce registry reconciliation."""
        if self.guardian_client is not None:
            if registry_digest:
                self.guardian_client.reconcile_registry(registry_digest=registry_digest, **binding)
            return self.guardian_client.snapshot()

        now = time.monotonic_ns() if now_monotonic_ns is None else now_monotonic_ns
        expired = []
        revoked = []
        with self._lock:
            self._reap_expired_locked(now)
            # 1. Expiration cleanup & 2. Registry drift detection
            for lease_id, (lease, sock, _) in self._leases.items():
                if lease.expires_at_monotonic_ns and now >= lease.expires_at_monotonic_ns:
                    expired.append(lease_id)
                elif registry_digest and lease.registry_digest and registry_digest != lease.registry_digest:
                    revoked.append(lease_id)

            for lease_id in expired + revoked:
                if lease_id in self._leases:
                    lease, sock, _ = self._leases.pop(lease_id)
                    try:
                        sock.close()
                    except Exception:
                        pass

        return self.snapshot()

    def persist_receipts(self, path: str | Path) -> None:
        """Persist non-secret lease receipts with comprehensive metadata for recovery."""
        # Convert Enums to strings for JSON serialization
        data = []
        for lease in self.snapshot():
            lease_dict = lease.__dict__.copy()
            lease_dict['lifecycle_state'] = lease.lifecycle_state.name
            lease_dict['health_state'] = lease.health_state.name
            data.append(lease_dict)
            
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(data, sort_keys=True), encoding="utf-8")

    @staticmethod
    def load_receipts(path: str | Path) -> tuple[PortLease, ...]:
        """Load receipts, restoring Enums from persisted strings."""
        if not Path(path).exists():
            return ()
        values = json.loads(Path(path).read_text(encoding="utf-8"))
        leases = []
        for item in values:
            # Restore Enums
            item['lifecycle_state'] = LifecycleState[item['lifecycle_state']]
            item['health_state'] = HealthState[item['health_state']]
            leases.append(PortLease(**item))
        return tuple(leases)
