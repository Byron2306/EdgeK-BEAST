from pathlib import Path

from benchmarks.c4x_document_truth_arena import run_document_truth_arena
from benchmarks.c4x_freeze_identities import freeze_identities


def test_freeze_identities_writes_core_and_truth_stack_receipt(tmp_path: Path):
    receipt = freeze_identities(evidence_root=tmp_path, run_id="pytest-freeze")

    assert receipt["beast_object_type"] == "c4x_freeze_identity_receipt"
    assert receipt["identities"]["c4x-core-v1.0"]["all_files_present"] is True
    assert receipt["identities"]["c4x-core-v1.0"]["identity_digest"].startswith("sha256:")
    assert "truth" in receipt["certificate_contract"]
    assert (tmp_path / "pytest-freeze" / "freeze_identities.json").is_file()
    assert (tmp_path / "pytest-freeze" / "freeze_identities.md").is_file()


def test_document_truth_arena_exports_real_pdf_audit_packets(tmp_path: Path):
    pdf = Path("docs/external/obsidian-beast/Blurred Text Extraction Limitations.pdf")
    receipt = run_document_truth_arena(
        corpus=(pdf,),
        evidence_root=tmp_path,
        run_id="pytest-document-arena",
        render_first_page=True,
    )
    root = tmp_path / "pytest-document-arena"

    assert receipt["beast_object_type"] == "c4x_document_truth_arena"
    assert receipt["scorecard"]["real_pdf_count"] == 1
    assert receipt["scorecard"]["truth_credit_awarded"] is False
    assert receipt["corpus"][0]["sha256"].startswith("sha256:")
    assert receipt["corpus"][0]["first_page_image"]["status"] == "ok"
    assert (root / "audit_packets" / "document_corpus.jsonl").is_file()
    assert (root / "audit_packets" / "document_corpus.csv").is_file()
    assert (root / "audit_packets" / "zotero_items.json").is_file()
    assert (root / "audit_packets" / "gemini_vs_human_protocol.jsonl").is_file()
    assert (root / "SHA256SUMS.txt").is_file()
