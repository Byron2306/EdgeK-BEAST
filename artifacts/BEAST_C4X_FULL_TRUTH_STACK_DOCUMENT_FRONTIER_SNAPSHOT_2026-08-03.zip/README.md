# BEAST C4-X Full Truth Stack + Document Frontier Snapshot

Includes:

- Frozen `c4x-core-v1.0` and `beast-truth-stack-v1.0` identities
- C4-X Truth Arena with RAG War, KV War, provider evidence, and custody gates
- Live Aurora pgvector RAG evidence
- Real local scientific/PDF document frontier audit packets
- Zotero-style JSON, CSV, JSONL, and Gemini-vs-human protocol export

No `.beast` env files, API keys, DSNs, IAM tokens, passwords, or provider secrets are included.

Important boundary: document frontier truth credit is intentionally false until native Gemini vision, blinded human inspection, table/chart annotations, and oracle sidecars are supplied.
