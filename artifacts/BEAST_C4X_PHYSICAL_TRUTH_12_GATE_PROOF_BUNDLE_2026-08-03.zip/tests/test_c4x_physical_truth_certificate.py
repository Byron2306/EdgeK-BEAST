import json
from pathlib import Path

from app.kernel.compute.c4x_physical_truth_certificate import (
    REQUIRED_LAYERS,
    build_c4x_physical_truth_certificate,
    empty_pending_sidecar,
)
from app.kernel.compute.deterministic_intelligence import sha256_digest
from scripts.run_c4x_physical_truth_certificate import run_physical_truth_certificate


def test_empty_physical_truth_certificate_refuses_all_public_credit():
    receipt = build_c4x_physical_truth_certificate(run_id="pytest-empty", **empty_pending_sidecar())

    assert receipt["public_credit_allowed"] is False
    assert receipt["truth_claim_allowed"] is False
    assert set(receipt["critical_failures"]) == set(REQUIRED_LAYERS)
    assert all(passed is False for passed in receipt["certificate_gates"].values())
    assert receipt["no_averaging_rule"] is True


def test_internal_provider_count_is_not_bpf_zero_provider_proof():
    sidecar = _complete_sidecar()
    sidecar["bpf_receipt"] = {
        "receipt_digest": sha256_digest({"bpf": "self-report-only"}),
        "provider_calls_used": 0,
    }

    receipt = build_c4x_physical_truth_certificate(run_id="pytest-bpf-refusal", **sidecar)

    assert receipt["certificate_gates"]["c4x_truth"] is True
    assert receipt["certificate_gates"]["bpf_witness"] is False
    assert receipt["public_credit_allowed"] is False
    bpf = [item for item in receipt["layer_verdicts"] if item["layer"] == "bpf_witness"][0]
    assert "outbound_connect_attempts" in bpf["missing"]
    assert "live_provider_comparator_observed_network" in bpf["missing"]


def test_complete_physical_truth_sidecar_allows_public_credit():
    receipt = build_c4x_physical_truth_certificate(run_id="pytest-complete", **_complete_sidecar())

    assert receipt["public_credit_allowed"] is True
    assert receipt["truth_claim_allowed"] is True
    assert receipt["critical_failures"] == []
    assert all(receipt["certificate_gates"].values())


def test_physical_truth_script_writes_pending_template_and_receipt(tmp_path: Path):
    receipt = run_physical_truth_certificate(evidence_root=tmp_path, run_id="pytest-physical", write_template=True)

    root = tmp_path / "pytest-physical"
    assert receipt["public_credit_allowed"] is False
    assert (root / "physical_truth_sidecar_template.json").is_file()
    assert (root / "physical_truth_certificate.json").is_file()
    assert (root / "physical_truth_certificate.md").is_file()
    assert (root / "SHA256SUMS.txt").is_file()


def test_physical_truth_script_accepts_complete_sidecar(tmp_path: Path):
    sidecar = tmp_path / "complete-sidecar.json"
    sidecar.write_text(json.dumps(_complete_sidecar(), indent=2, sort_keys=True) + "\n", encoding="utf-8")

    receipt = run_physical_truth_certificate(sidecar=sidecar, evidence_root=tmp_path, run_id="pytest-complete-script")

    assert receipt["public_credit_allowed"] is True
    assert json.loads((tmp_path / "pytest-complete-script" / "physical_truth_certificate.json").read_text())["receipt_digest"] == receipt["receipt_digest"]


def _complete_sidecar():
    return {
        "c4x_receipt": _with_digest({
            "proof_first": True,
            "joined_verification": True,
            "text_artifact_digest_valid": True,
            "visual_artifact_digest_valid": True,
            "unsupported_gaps_refused": True,
            "provider_calls_used": 0,
        }),
        "sensorium_receipt": _with_digest({
            "ordered_episode": True,
            "journal_integrity_valid": True,
            "explicit_loss_accounting": True,
            "raw_sensitive_payloads_absent": True,
            "observer_lifecycle_recorded": True,
            "missing_observations_lower_authority": True,
        }),
        "bpf_receipt": _with_digest({
            "read_only_program": True,
            "cgroup_bound": True,
            "outbound_connect_attempts": 0,
            "dns_activity": 0,
            "provider_sockets_opened": 0,
            "unexpected_child_processes": 0,
            "live_provider_comparator_observed_network": True,
            "ring_loss_explicit": True,
            "raw_packet_payload_retained": False,
        }),
        "crystal_bus_receipt": _with_digest({
            "af_unix_seqpacket": True,
            "so_peercred_bound": True,
            "session_id_bound": True,
            "message_mac_or_signature_verified": True,
            "sequence_replay_rejected": True,
            "durable_high_water_checked": True,
            "capability_lease_required": True,
            "arda_appraisal_required": True,
            "fd_count_type_seals_digest_verified": True,
            "sender_death_after_handoff_verified": True,
            "revocation_replay_rejected": True,
        }),
        "memfd_receipt": _with_digest({
            "sealed_memfd": True,
            "seal_write": True,
            "seal_grow": True,
            "seal_shrink": True,
            "seal_seal": True,
            "digest_verified_after_seal": True,
            "mutation_attempt_rejected": True,
            "wrong_fd_type_rejected": True,
        }),
        "guardian_receipt": _with_digest({
            "separate_process": True,
            "scm_rights_handoff_verified": True,
            "process_lease_verified": True,
            "one_use_render_capability_consumed": True,
            "replay_render_capability_rejected": True,
            "wrong_uid_rejected": True,
            "expired_lease_rejected": True,
            "producer_death_after_handoff_verified": True,
            "joined_custody_receipt_signed": True,
        }),
        "reuse_receipt": _with_digest({
            "exact_prefix_hit_verified": True,
            "identity_mismatch_refused": True,
            "corrupt_payload_rejected": True,
            "restart_persistence_credit_only_if_demonstrated": True,
            "cross_engine_import_refused_without_physical_success": True,
            "crystal_composition_reuse_verified": True,
            "semantic_truth_points_not_awarded_for_kv_speed": True,
        }),
        "pq_transport_receipt": _with_digest({
            "ml_kem_active": True,
            "ml_dsa_signature_verified": True,
            "fallback": False,
            "recipient_decapsulation_verified": True,
            "ciphertext_tamper_rejected": True,
            "signature_tamper_rejected": True,
            "replay_nonce_unused": True,
            "artifact_digest_verified": True,
            "policy_scope_accepted": True,
        }),
        "commons_receipt": _with_digest({
            "imported_as_quarantined_hypothesis": True,
            "clean_source_rebuild": True,
            "independent_seed": True,
            "independent_oracle": True,
            "reproduction_successful": True,
            "promotion_after_local_success_only": True,
            "node_count_minimum_met": True,
        }),
        "route_receipt": _with_digest({
            "deterministic_failure_schedule_hidden_from_router": True,
            "attestation_failure_immediate_suppression": True,
            "timeout_accumulates_penalty": True,
            "429_suppression": True,
            "recovery_after_decay": True,
            "oscillation_bounded": True,
            "decision_receipts_explain_route_change": True,
            "beats_no_damping_retry_and_circuit_breaker": True,
        }),
        "psi_receipt": _with_digest({
            "cpu_pressure_case": True,
            "memory_pressure_case": True,
            "io_pressure_case": True,
            "near_oom_case": True,
            "disk_full_or_inode_case": True,
            "evidence_not_corrupted": True,
            "sensorium_loss_not_silent": True,
            "low_priority_work_shed_first": True,
            "proof_and_custody_preserved": True,
            "refused_before_corrupting_evidence": True,
        }),
        "xdp_receipt": _with_digest({
            "isolated_veth_or_namespace": True,
            "redirect_pass_drop_observed": True,
            "unauthorized_cgroup_rejected": True,
            "worker_death_observed": True,
            "rx_ring_loss_reported": True,
            "xdp_detach_detected": True,
            "no_unrelated_traffic_redirected": True,
            "policy_fail_open_or_closed_verified": True,
            "guardian_policy_not_bypassed": True,
        }),
    }


def _with_digest(payload):
    return {**payload, "receipt_digest": sha256_digest(payload)}
